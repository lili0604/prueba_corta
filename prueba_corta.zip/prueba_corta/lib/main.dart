import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Prueba de Programación Flutter',
      home: MyHomePage(),
    );
  }
}

class _MyHomePageState extends State<MyHomePage> {
  // StreamController para emitir los datos
  final StreamController<String> _streamController =
      StreamController.broadcast();

  // Lista de datos para mostrar en el ListView
  List<String> _data = [];

  // Timer para emitir nuevos datos en el Stream
  late Timer _timer;

  @override
  void initState() {
    super.initState();

    // Inicializamos el temporizador para emitir nuevos datos cada 2 segundos
    _timer = Timer.periodic(Duration(seconds: 2), (_) => _emitData());
  }

  @override
  void dispose() {
    // Nos aseguramos de cancelar el temporizador antes de destruir el widget
    _timer.cancel();

    // Cerramos el StreamController
    _streamController.close();

    super.dispose();
  }

  // Método para emitir nuevos datos en el Stream
  void _emitData() {
    // Generamos un nuevo dato aleatorio
    String data = "Data ${_data.length + 1}";

    // Emitimos el dato en el Stream
    _streamController.add(data);

    // Agregamos el dato a la lista de datos
    _data.add(data);

    // Actualizamos el ListView
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Prueba de Programación Flutter'),
      ),
      body: StreamBuilder<String>(
        stream: _streamController.stream,
        builder: (context, snapshot) {
          // Si el Stream está activo
          if (snapshot.connectionState == ConnectionState.active) {
            // Si hay datos disponibles
            if (snapshot.hasData) {
              // Devolvemos el ListView con los datos
              return ListView.builder(
                itemCount: _data.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(_data[index]),
                  );
                },
              );
            } else {
              // Devolvemos un mensaje de error
              return Center(child: Text('No hay datos disponibles'));
            }
          } else {
            // Si el Stream está esperando
            if (snapshot.connectionState == ConnectionState.waiting) {
              // Devolvemos un mensaje de espera
              return Center(child: Text('Esperando datos...'));
            } else {
              // Si el Stream está en error
              if (snapshot.hasError) {
                // Devolvemos un mensaje de error
                return Center(child: Text('Error: ${snapshot.error}'));
              } else {
                // Devolvemos un mensaje vacío
                return Container();
              }
            }
          }
        },
      ),
    );
  }
}

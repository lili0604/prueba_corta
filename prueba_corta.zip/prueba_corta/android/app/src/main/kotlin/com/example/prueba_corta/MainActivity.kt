package com.example.prueba_corta

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
